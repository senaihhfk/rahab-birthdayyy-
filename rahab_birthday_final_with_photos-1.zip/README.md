# Rahab Birthday Website 🎀🌷🤍

This final version includes all 8 photos from the two uploaded collages.

Put the chosen song URL into MUSIC_LINK in script.js, then upload the folder to GitHub and deploy it with Vercel.
